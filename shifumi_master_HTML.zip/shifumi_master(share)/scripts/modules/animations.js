const animations = {
    slideup: [
        { transform: 'translateY(100%)' },
        { transform: 'translateY(0)' }
    ],

    slideright: [
        { transform: 'translateX(-100%)' },
        { transform: 'translateX(0)' }
    ],

    fadein: [
        { opacity: 0 },
        { opacity: 1 }
    ]
}