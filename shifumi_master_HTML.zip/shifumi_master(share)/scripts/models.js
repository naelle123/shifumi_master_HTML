const Game = {
    MAX_TURN: 5   
}

const KEY_PLAYER_LIST = 'SHIFUMI_MASTER_PLAYERS'

//localStorage.removeItem(KEY_PLAYER_LIST)

function getDBplayers() {
    const parseList = localStorage.getItem(KEY_PLAYER_LIST)

    if (parseList) {
        return JSON.parse(parseList)
    } else {
        const newArray = []
        localStorage.setItem(KEY_PLAYER_LIST, JSON.stringify(newArray))
        console.log('creating new');
        return newArray
    }
}

function savePlayer(...players) {
    const playerList = getDBplayers()
    players.forEach(player => {
        const result = playerList.find(p => p.name === player.name)

        if (result) {
            const resultIndex = playerList.indexOf(result)
            playerList[resultIndex] = player
        } else {
            playerList.push(player)
        }
    })

    localStorage.setItem(KEY_PLAYER_LIST, JSON.stringify(playerList))
}

function updatePlayer(playerName, field, value, del) {
    let playerList = getDBplayers()
    if (del) {
        const newArray = playerList.filter(p => p.name !== playerName)
        playerList = newArray
    } else {
        const result = playerList.find(p => p.name === playerName)
        const resultIndex = playerList.indexOf(result)
        playerList[resultIndex][field] = value
    }

    localStorage.setItem(KEY_PLAYER_LIST, JSON.stringify(playerList))
}

function getPlayer(playerName) {
    const playerList = getDBplayers()
    let searchPlayer

    playerList.forEach(player => {
        if (player.name === playerName) 
            searchPlayer = player
    });
    
    return searchPlayer
}

function getLevel(points) {
    const luckPoints = getLuckPoints(points)
    if (luckPoints >= 0 && luckPoints < 5) return 'En danger'
    if (luckPoints >= 5 && luckPoints < 10) return 'Survivant'
    if (luckPoints >= 10 && luckPoints < 15) return 'Protegé'
    if (luckPoints >= 15 && luckPoints < 25) return 'Tres Chanceux'
    if (luckPoints >= 25 && luckPoints < 50) return 'Master Chance'
    if (luckPoints >= 50) return 'Inéluctable'
    return 'Master Chance'
}

function getLuckPoints(points) {
    const games = points.games ? points.games : 1
    const luckPoints = points.wins - (points.looses / (games))
    return luckPoints >= 0 ? luckPoints : 0
}

class Player {

    constructor({name = '', profile = '', points = new Points({})}) {
        this.name = name
        this.profile = profile
        this.points = points
    }
}

class Points {

    constructor({wins = 0, ties = 0, looses = 0}) {
        this.wins = wins
        this.ties = ties
        this.looses = looses
        this.games = 0
    }
}

class Move {

    constructor(move) {
        this.move = move

        Object.defineProperty(this, 'fail', {
            get: () => {
                if (this.move === 'rock') return 'paper'
                if (this.move === 'paper') return 'blades'
                if (this.move === 'blades') return 'rock'
            }
        })
    }
}