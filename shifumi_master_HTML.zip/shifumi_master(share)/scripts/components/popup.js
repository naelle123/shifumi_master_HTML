const alertDialogKey = 'key_page_alert'
const dialogKey = 'key_page_dialog'

class AlertDialog extends Page {

    constructor({transition = 'fadein', duration = 800, content = '', onValid = ''}) {
        super(alertDialogKey, 'modal', {transition, duration})
        this.transition = transition
        this.duration = duration
        this.content = content
        this.onValid = onValid
    }

    build() {
        return `
            <div class="alertDialog">

                <figure class="dialogHead">
                    <img src="assets/danger.png" alt="danger icon">
                </figure>

                <p class="dialogContent">
                    ${this.content}
                </p>

                <div class="dialogActions">
                    <button class="cancel" onclick="pop()">Cancel</button>
                    <button class="valid" onclick="${this.onValid}">D'accord</button>
                </div>

            </div>
        `
    }

}

class Dialog extends Page {

    constructor({transition = 'fadein', duration = 800, content = '', title = '', action = '', actionTitle = ''}) {
        super(dialogKey, 'modal', {transition, duration})
        this.transition = transition
        this.duration = duration
        this.content = content
        this.title = title
        this.action = action
        this.actionTitle = actionTitle
    }

    build() {
        return `
            <div class="dialog">

                <p class="dialogTitle">${this.title}</p>

                <div class="dialogContent">
                    ${this.content}
                </div>

                <button class="continue" onclick="${this.action ? this.action : "pop()"}">
                    ${this.actionTitle ? this.actionTitle : 'OK'}
                </button>

            </div>
        `
    }

}