const usersKey = 'key_page_users'

const profiles = [
    'assets/profiles/profile_1.jpg',
    'assets/profiles/profile_2.jpg',
    'assets/profiles/profile_3.jpeg',
    'assets/profiles/profile_4.jpeg',
    'assets/profiles/profile_5.jpeg',
]

function renamePlayer(playerName) {
    const value = document.getElementById('new_player_name').value
    console.log(playerName);

    updatePlayer(playerName, 'name', value)
    reloadUserList()
    pop()
}

function deletePlayer(playerName) {
    updatePlayer(playerName, '', '', true)
    reloadUserList()
    pop()
}

function updateProfile(playerName, value) {
    updatePlayer(playerName, 'profile', value)
    reloadUserList()
    pop()
}

function onProfile(playerName) {
    let content = `
        <div style="color: var(--confirmColor);">
            <p class="pseudoLink" onclick="updateProfile('${playerName}', '${profiles[0]}')"> Photo 1: Homme Guerrier </p>
            <p class="pseudoLink" onclick="updateProfile('${playerName}', '${profiles[1]}')"> Photo 2: Femme Guerrière </p>
            <p class="pseudoLink" onclick="updateProfile('${playerName}', '${profiles[2]}')"> Photo 3: Futaro </p>
            <p class="pseudoLink" onclick="updateProfile('${playerName}', '${profiles[3]}')"> Photo 4: Maki Chan </p>
            <p class="pseudoLink" onclick="updateProfile('${playerName}', '${profiles[4]}')"> Photo 5: Hideki </p>
        </div>
    `
    push(new Dialog({
        title: 'Renommer',
        content,
        actionTitle: 'Retourner',
        action: 'pop()'
    }))
}

function onDelete(playerName) {
    push(new Dialog({
        title: 'Renommer',
        content: `
            <p style="color: var(--danger-color)">
                Etes-vous sure de vouloir supprimer ce joueur ?
            </p>
        `,
        actionTitle: 'Confirmer',
        action: `deletePlayer('${playerName}')`
    }))
}

function onRename(playerName) {
    const content = `
        <div> 
            <p> 
                <label for="new_player_name"> Nouveau Nom </label>
            </p>
            <input type="text" id="new_player_name" class="customInput" 
                style="border-color: black; margin-top: 4px; color: black;"/>
        </div>
    `

    push(new Dialog({
        title: 'Renommer',
        content,
        actionTitle: 'Confirmer',
        action: `renamePlayer('${playerName}')`
    }))
}

function reloadUserList() {
    const listBox = document.querySelector('.playerList')

    listBox.innerHTML = getUsersChildren()
}

function getUsersChildren() {
    const users = getDBplayers()
    let content = ''

    users.forEach(user => {
        content += `
            <li class="playerBoxHolder">
                <div class="playerBox">
                    <figure class="profileHolder">
                        <img src=${user.profile} alt="profile ${user.name}">
                    </figure>
                    <div class="playerInfos">
                        <p class="playerName">
                            Nom: <span>${user.name}</span>
                        </p>
                        <p class="playerLevel" style="margin-top: 4px;">
                            Niveau: <span style="color: var(--confirmColor)">${getLevel(user.points)}</span>
                        </p>
                    </div>
                </div>
                <button class="icon">
                    <img src="assets/more.png" alt="more options icon">
                    <div class="playerOptions">
                        <span onclick='onProfile("${user.name}")'>Changer la Photo</span>
                        <span onclick='onRename("${user.name}")'>Renommer</span>
                        <span style="color: var(--danger-color);" onclick='onDelete("${user.name}")'>Supprimer</span>
                    </div>
                </button>
            </li>
        `
    });

    return content
}

class UsersPage extends Page {

    constructor({transition = 'slideup', duration = 1200, includePop = true}) {
        super(usersKey, 'modal', {includePop, transition, duration})
        this.transition = transition
        this.duration = duration
    }

    build() {
        return `
            <div class="container users">
                <h2 style="text-align: center;">Liste des joueurs</h2>

                <div>
                    <ul class="playerList scrollable">${getUsersChildren()}</ul>
                </div>
            </div>
        `
    }

}