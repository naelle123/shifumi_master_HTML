const leaderKey = 'key_page_leader'

function showStats(encodedPlayer) {
    const player = JSON.parse(decodeURIComponent(encodedPlayer))
    const content = `
        <p style="width: 200px;">Joueur: <span style="font-weight: bold;">${player.name}</span></p>
        <p>Niveau: <span style="font-weight: bold; color: var(--confirmColor);">${getLevel(player.points)}</span></p>
        <p>Victoires: <span style="font-weight: bold;">${player.points.wins}</span></p>
        <p>Defaites: <span style="font-weight: bold;">${player.points.looses}</span></p>
        <p>Egalités: <span style="font-weight: bold;">${player.points.ties}</span></p>
        <p>Parties jouées: <span style="font-weigth: bold; color: var(--yellow);">${player.points.games}</span></p>
    `
    push(new Dialog({
        content: content,
        title: 'Stats'
    }))
}

function getLeaderChildren() {
    const players = getDBplayers()
    players.sort((a, b) => {
        const a_score = getLuckPoints(a.points)
        const b_score = getLuckPoints(b.points)

        return (a_score - b_score) * -1
    })
    
    const topPlayers = players.slice(0, players.length > 10 ? 10 : players.length)
    let content = ''

    topPlayers.forEach((player, index) => {
        content += `
            <li class="rankerBox" onclick="showStats('${encodeURIComponent(JSON.stringify(player))}')">
                <p class="rank">${index}.</p>
                <figure class="profile">
                    <img src=${player.profile} alt="profile du joueur ${player.name}">
                </figure>
                <div class="rankerInfo">
                    <p>${player.name}</p>
                    <p>points chance : <span>${getLuckPoints(player.points)}</span></p>
                </div>
            </li>
        `
    });

    return content
}

class LeaderPage extends Page {

    constructor({transition = 'slideright', duration = 800, includePop = true}) {
        super(leaderKey, 'container leader', {includePop, transition, duration})
        this.transition = transition
        this.duration = duration
    }

    build() {
        return `
            <div class="leaderboard">

                <div class="leaderbox">
                    <h2>Leaderboard</h2>

                    <ul class="rankerList scrollable">${getLeaderChildren()}</ul>
                </div>

                <div class="options" style="margin-left: 2rem;">
                    <button class="icon">
                        <img src="assets/menu.png" alt="leaderboard menu icon">
                    </button>
                    <div class="optionsBox">
                        <span class="pseudoLink" onclick="push(new UsersPage({}))">Consulter Liste des Joueurs</span>
                    </div>
                </div>
            </div>
        `
    }

}