const menuKey = 'key_page_menu'

const links = [
    {
        title: 'P1 vs IA',
        action: 'push(new SelectionPage({useAi: true}))'
    },
    {
        title: 'P1 vs P2',
        action: 'push(new SelectionPage({}))'
    },
    {
        title: 'Leaderboard',
        action: 'push(new LeaderPage({}))'
    },
    {
        title: 'Quit',
        action: `push(new AlertDialog({
            content: 'Etes-vous sure de vouloir nous quitter ?',
            onValid: 'window.close()'
        }))`
    },
]

function getChildren(children) {
    const childrenContent = children.map(link => {
        return `
            <li>
                <button class="outlined" onclick="${link.action}">${link.title}</button>
            </li>
        `
    })

    let finalContent = ''
    childrenContent.forEach(content => {
        finalContent += content
    });

    return finalContent
}

class MenuPage extends Page {

    constructor({transition = 'slideup', duration = 1200}) {
        super(menuKey, 'container', {})
        this.transition = transition
        this.duration = duration
    }

    build() {
        return `
            <div class="mainMenu w-full">
                <h1>Shifumi Master</h1>

                <ul id="menu" class="w-full">
                    ${getChildren(links)}
                </ul>
            </div>
        `
    }

}