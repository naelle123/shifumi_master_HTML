const gameKey = 'key_page_game'

let p1
let p2
let ai = false

let player1_move = ''
let player2_move = ''
let score = {
    p1: 0,
    p2: 0
}
let turn = 0

function endGame() {
    score.p1 = 0
    score.p2 = 0
    turn = 0
    pushClearAll(new MenuPage({}))
    if (ai) savePlayer(p1)
    else savePlayer(p1, p2) 
}

function nextStep() {
    turn += 1
    player1_move = ''
    player2_move = ''
    if (turn >= Game.MAX_TURN) {

        return push(new Dialog({
            title: 'Terminé',
            content: `
                vainqueur: <span style="font-weight: bold;"> ${compareScores()} </span>
            `,
            action: "endGame()",
            actionTitle: 'continuer'
        }))
    }
    const balls = document.querySelectorAll('.ball')
    balls.forEach(ball => {
        ball.classList.remove('active')
    })

}

function compareScores() {
    if (score.p1 > score.p2) return p1.name
    else if(score.p1 < score.p2) return p2.name
    else return "Personne les nuls c'est une Egalité !!"
}

function playMove(player, move) {
    
    if (player === 1 && !player1_move) player1_move = move
    else if (player === 2 && !player2_move) player2_move = move

    selectMoveBall(player, move)

    if (ai) {
        player2_move = getRandomMove()
        selectMoveBall(2, player2_move)
    }

    if (player1_move && player2_move) {
        setTimeout(()=> {
            compareResults()
        }, 2000)
    }

}

function compareResults() {
    if (player1_move === player2_move) {
        p1.points.ties += 1
        p2.points.ties += 1
        return nextStep()
    }
    const p1Score = document.querySelector('.js-p1-score')
    const p2Score = document.querySelector('.js-p2-score')

    if (new Move(player1_move).fail === player2_move) {
        score.p2 += 1
        p2.points.wins +=1
        p1.points.looses += 1
        p2Score.innerHTML = `${score.p2}`
    }
    else {
        score.p1 += 1
        p1.points.wins += 1
        p2.points.looses += 1
        p1Score.innerHTML = `${score.p1}`
    }
        
    nextStep()
}

function getRandomMove() {
    const ran = Math.random()
    if (ran >= 0 && ran <= 0.36) return 'rock'
    if (ran > 0.36 && ran <= 0.7) return 'paper'
    if (ran > 0.7 && ran < 1) return 'blades'
}

function selectMoveBall(player, move) {
    const playerBox = document.querySelector(`.balls-center.p${player}`)
    const ball = playerBox.querySelector(`.ball.${move}`)
    ball.classList.add('active')
}

class GamePage extends Page {

    constructor({transition = 'fadein', duration = 1200, includePop = false, participants = {}}) {
        super(gameKey, 'container game', {includePop, transition, duration})
        this.transition = transition
        this.duration = duration
        this.player1 = participants.player1
        this.player2 = participants.player2
        this.useAi = this.player2.name === 'Shifumi Ai'
        this.onInit()
    }

    onpop() {
        console.log('login out');
        push(new AlertDialog({
            content: `Are you sure you want to quit, all the data will be lost still continue ?`,
            onValid: 'pushClearAll(new MenuPage({}))'
        }))
    }
    onInit() {
        p1 = this.player1
        p2 = this.player2
        p1.points.games += 1
        p2.points.games += 1
        ai = this.useAi
    }

    build() {
        return `
            <div class="scoreBar center-flex">

                <p class="pInfo">
                    <span class="js-p1-score" style="margin-right: 8px; color: var(--confirmColor);">0</span>
                    <span class="js-p1-name">${this.player1.name}</span>
                </p>

                <div class="tilde"></div>

                <p class="pInfo">
                    <span class="js-p2-score" style="margin-left: 8px; color: var(--confirmColor);">0</span>
                    <span class="js-p1-name">${this.player2.name}</span>
                </p>

            </div>

            <div id="gameBox" class="w-full">

                <div class="playerZone js-p1">

                    <div class="animatedBoard center-flex">
                        <div class="profile">
                            <img src=${this.player1.profile} alt="${this.player1.name} profile">
                        </div>

                        <div class="balls-center p1 cover">
                            <div class="ball blades" id="ball1">
                                <img src="assets/blades.png" alt="blades ball">
                            </div>
                            <div class="ball rock" id="ball2">
                                <img src="assets/stone.png" alt="rock ball">
                            </div>
                            <div class="ball paper" id="ball3">
                                <img src="assets/paper.png" alt="paper ball">
                            </div>
                        </div>
                    </div>

                    <div class="movesBoard">
                        <p style="margin-left: -20px; font-weight: bold;">
                            actions :
                        </p>
                        
                        <ul class="moveList">
                            <li class="moveBox" onclick="playMove(1, 'rock')">
                                <img src="assets/rock-hand.png" alt="mouvement pierre">
                                <p class="tooltip">Pierre</p>
                            </li>
                            <li class="moveBox" onclick="playMove(1, 'paper')">
                                <img src="assets/paper-hand.png" alt="mouvement papier">
                                <p class="tooltip">Papier</p>
                            </li>
                            <li class="moveBox" onclick="playMove(1, 'blades')">
                                <img src="assets/scissors-hand.png" alt="mouvement ciseau">
                                <p class="tooltip">Ciseau</p>
                            </li>
                        </ul>
                    </div>
                
                </div>

                <div class="resultZone center-flex">

                    <figure id="imgHolder" style="margin-bottom: 4rem;">
                        <img src="assets/stone.png" alt="power move image">
                    </figure>

                </div>

                <div class="playerZone js-p2">

                    <div class="animatedBoard center-flex">
                        <div class="profile">
                            <img src=${this.player2.profile} alt="${this.player2.name} profile">
                        </div>
                        <div class="balls-center p2 cover">
                            <div class="ball blades" id="ball1">
                                <img src="assets/blades.png" alt="blades ball">
                            </div>
                            <div class="ball rock" id="ball2">
                                <img src="assets/stone.png" alt="rock ball">
                            </div>
                            <div class="ball paper" id="ball3">
                                <img src="assets/paper.png" alt="paper ball">
                            </div>
                        </div>
                    </div>

                    ${
                        !this.useAi 
                            ? `
                            <div class="movesBoard">
                                <p style="margin-left: -20px; font-weight: bold;">
                                    actions :
                                </p>
                                
                                <ul class="moveList">
                                    <li class="moveBox" onclick="playMove(2, 'rock')">
                                        <img src="assets/rock-hand.png" alt="mouvement pierre">
                                        <p class="tooltip">Pierre</p>
                                    </li>
                                    <li class="moveBox" onclick="playMove(2, 'paper')">
                                        <img src="assets/paper-hand.png" alt="mouvement papier">
                                        <p class="tooltip">Papier</p>
                                    </li>
                                    <li class="moveBox" onclick="playMove(2, 'blades')">
                                        <img src="assets/scissors-hand.png" alt="mouvement ciseau">
                                        <p class="tooltip">Ciseau</p>
                                    </li>
                                </ul>
                            </div>
                            `
                            : ''
                    }
                </div>

            </div>
        `
    }

}