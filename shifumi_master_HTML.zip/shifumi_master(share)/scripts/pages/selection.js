const selectionKey = 'key_page_selection'

let player1;
let player2;

function onInputChange(e) {
    const parent = e.target.parentNode
    const validBtn = parent.querySelector('.selectAction')
    const value = e.target.value
    
    if (value)
        validBtn.classList.add('active')
    else 
        validBtn.classList.remove('active')
}

function selectPlayer(player, useAi) {

    const input = document.getElementById(`player${player}_name`)
    const box = document.getElementById(`selected_${player}`)
    let playerObj;
    const storedPlayer = getPlayer(input.value)

    if (storedPlayer) {
        playerObj = storedPlayer

    } else {
        playerObj = new Player({
            name: input.value,
        })
    }

    if (player === 1 ) {
        player1 = playerObj
        player1.profile = player1.profile || 'assets/profiles/profile_1.jpg'
    } else {
        player2 = playerObj
        player2.profile = player2.profile || 'assets/profiles/profile_2.jpg'
    }

    renderSelected(box, playerObj)

    if (useAi) {
        player2 = new Player({
            name: 'Shifumi Ai',
            profile: 'assets/profiles/profile_ai.jpg'
        })
        renderSelected(document.getElementById('selected_2'), player2)
    }

    if (player1 && player2) {
        startGame()
    }
}

function startGame() {
    setTimeout(()=> {
        push(new GamePage({
            includePop: true,
            participants: {player1, player2}
        }))
        player1 = ''
        player2 = ''
    }, 2000)
}

function renderSelected(box, playerInfos) {
    box.innerHTML = `
        <div class="selectedPlayerBox">
            <figure class="profile">
                <img src="${playerInfos.profile}" alt="${playerInfos.name}'s profile">
            </figure>
            <div style="margin-left: 12px"></div>
            <div class="selectedPlayerInfos">
                <p class="selectedPlayerName">
                    Nom: <span style="font-weight: bold; color:var(--yellow);">${playerInfos.name}</span>
                </p>
                <p class="selectedPlayerLv">
                    Niveau: 
                    <span style="font-weight: bold; color:var(--confirmColor);">
                        ${playerInfos.name === 'Shifumi Ai' ? 'Non Identifié' : getLevel(playerInfos.points)}
                    </span>
                </p>
            </div>
        </div>
    `
}

class SelectionPage extends Page {

    constructor({transition = 'slideup', duration = 600, includePop = true, useAi = false}) {
        super(selectionKey, 'selectContainer', {includePop, transition, duration})
        this.transition = transition
        this.duration = duration
        this.useAi = useAi
    }

    build() {
        return `
            <h2 style="text-align: center;">Player Selection</h2>

            <div class="inputs" style="margin-top: 2rem;">
                <div class="inputBox">
                    <label for="player1_name">Player 1 :</label>
                    <input type="text" id="player1_name" class="customInput" oninput="onInputChange(event)">
                    <button class="selectAction" onclick="selectPlayer(1, ${this.useAi})">OK</button>
                </div>
                <div class="inputBox">
                    <label for="player2_name">Player 2 :</label>
                    <input type="text" id="player2_name" class="customInput" 
                        oninput="onInputChange(event)" ${this.useAi ? 'disabled' : ''}>
                    <button class="selectAction" onclick="selectPlayer(2, ${this.useAi})">OK</button>
                </div>
            </div>

            <div class="selectedList">

                <div id="selected_1"></div>

                <figure class="versusBlades">
                    <img src="assets/blades.png" alt="Versus blades images">
                </figure>

                <div id="selected_2"></div>

            </div>
        `
    }

}