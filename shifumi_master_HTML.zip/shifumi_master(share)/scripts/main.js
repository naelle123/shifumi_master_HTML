const popUp = new Dialog({
    content: `Salut Bienvenue sur <strong>Shifumi MASTER</strong> !!! Appuies sur le bouton suivant et lance la musique 
        <i>(Ps: Verifie que ton volume n'est pas trop fort)</i>`,
    title: 'Bienvenue',
    action: 'commencer()'
})

const mainAudio = new Audio('assets/sounds/background_bleach.mp3')
mainAudio.loop = true

function commencer() {
    pushClearAll(new MenuPage({}))
    mainAudio.play()
}

push(popUp)